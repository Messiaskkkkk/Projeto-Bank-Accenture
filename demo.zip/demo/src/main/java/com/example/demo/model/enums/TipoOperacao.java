package com.example.demo.model.enums;

public enum TipoOperacao {
	SAQUE, DEPOSITO, TRANSFERENCIA
}

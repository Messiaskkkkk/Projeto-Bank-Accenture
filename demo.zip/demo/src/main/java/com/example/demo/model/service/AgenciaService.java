package com.example.demo.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
import com.example.demo.repository.AgenciaRepository;
import com.example.demo.model.Agencia;
import com.example.demo.model.Agencia;

@Service
public class AgenciaService {
	
	@Autowired
	private AgenciaRepository agenciaRepository;
	
	@Transactional(readOnly = true)
	public List<Agencia> listarAgencias(){
		return agenciaRepository.findAll();
	}
	
	@Transactional(readOnly = true)
	public Agencia listarAgenciaPorId(Long id) {
		Agencia agencia = agenciaRepository.findById(id).orElse(null);
		return agencia;
	}
	
	@Transactional(readOnly = false)
	public Agencia cadastrarAgencia(Agencia agencia){
		return agenciaRepository.save(agencia);
	}
	
	@Transactional(readOnly = false)
	public Agencia atualizarAgencia(Agencia agencia){
		return agenciaRepository.save(agencia);
	}
	
	@Transactional(readOnly = false)
	public String deletarAgenciaPorId(Agencia agencia) {
		Long id = agencia.getIdAgencia();
		agenciaRepository.deleteById(agencia.getIdAgencia());
		return "Agencia de id " + id + " deletada com sucesso";
	}

	
	
	
}

package com.example.demo.model.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Service;
import com.example.demo.repository.ContaCorrenteRepository;
import com.example.demo.model.ContaCorrente;
import com.example.demo.model.ContaCorrente;

@Service
public class ContaCorrenteService {
	
	@Autowired
	private ContaCorrenteRepository contaCorrenteRepository;
	
	@Transactional(readOnly = true)
	public List<ContaCorrente> listarContaCorrentes(){
		return contaCorrenteRepository.findAll();
	}
	
	@Transactional(readOnly = true)
	public ContaCorrente listarContaCorrentePorId(Long id) {
		ContaCorrente contaCorrente = contaCorrenteRepository.findById(id).orElse(null);
		return contaCorrente;
	}
	
	@Transactional(readOnly = false)
	public ContaCorrente cadastrarContaCorrente(ContaCorrente contaCorrente){
		return contaCorrenteRepository.save(contaCorrente);
	}
	
	@Transactional(readOnly = false)
	public ContaCorrente atualizarContaCorrente(ContaCorrente contaCorrente){
		return contaCorrenteRepository.save(contaCorrente);
	}
	
	@Transactional(readOnly = false)
	public String deletarContaCorrentePorId(ContaCorrente contaCorrente) {
		Long id = contaCorrente.getIdContaCorrente();
		contaCorrenteRepository.deleteById(contaCorrente.getIdContaCorrente());
		return "Conta de id " + id + " deletada com sucesso";
	}

	
	
	
}


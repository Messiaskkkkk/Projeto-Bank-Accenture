package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.ContaCorrente;

public interface ContaCorrenteRepository extends JpaRepository<ContaCorrente,Long>{

}

